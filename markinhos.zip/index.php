<!DOCTYPE html>
<html lang="pt-BR">
    <?php include './header.php'; ?>
    <body>
        <?php
        include './classes/retornaSigno.php';
        if (isset($_POST['btnConsultarSigno'])) {
            $f['nome'] = filter_input(INPUT_POST, "nome", FILTER_DEFAULT);
            $f['dtNascimento'] = filter_input(INPUT_POST, "dtNascimento", FILTER_DEFAULT);

            $user = new StdClass();
            $user->nome = $f['nome'];
            $user->diaNascimento = date('d', strtotime($f['dtNascimento']));
            $user->mesNascimento = date('m', strtotime($f['dtNascimento']));

            $baseXML = simplexml_load_file('base.xml');

            $signo = signo($user->diaNascimento, $user->mesNascimento);

            foreach ($baseXML->signo as $sg) {
                if ($sg->signoNome == $signo) {
                    $resultadoDataInicial = $sg->dataInicio;
                    $resultadoDataFinal = $sg->dataFim;
                    $resultadoSigno = $sg->signoNome;
                    $resultadoDescricao = $sg->signoDescricao;
                }
            }
            ?>    
            <div class="container-contact100">
                <div class="wrap-contact100-form-btn">
                    <div class="wrap-contact100">
                        <h2 class="text-md-center">Olá <?= $user->nome ?>,<br>você é de <spam class="font-weight-bold"><?= $resultadoSigno ?></spam></h2>
                        <h3 class="text-md-center">Nascido entre <?= $resultadoDataInicial ?> a <?= $resultadoDataFinal ?></h3>
                        <p class="text-justify"><?= $resultadoDescricao ?></p> 
                        <button class="font-weight-bold contact100-form" name="btnRetorna" onclick="window.location.href = 'index.php';">
                            Consultar outro signo
                        </button>
                    </div>
                </div>
            </div>
        <?php } else {
            ?>
            <div class="container-contact100">
                <div class="wrap-contact100">
                    <form class="contact100-form validate-form" name="frmUser" method="post">
                        <span class="contact100-form-title">
                            Quem é você???
                        </span>
                        <div class="wrap-input100 validate-input" data-validate="O campo nome é obrigatório">
                            <input class="input100" id="nome" type="text" name="nome" placeholder="Digite seu nome" required>
                            <label class="label-input100" for="name">
                                <span class="lnr lnr-user"></span>
                            </label>
                        </div>
                        <div class="wrap-input100 validate-input" data-validate="Campo data de nascimento é obrigatório">
                            <input class="input100" id="dtNascimento" type="date" name="dtNascimento" placeholder="Digite sua data de nascimento" required>
                            <label class="label-input100" for="email">
                                <span class="lnr lnr-calendar-full"></span>
                            </label>
                        </div>
                        <div class="container-contact100-form-btn">
                            <div class="wrap-contact100-form-btn">
                                <div class="contact100-form-bgbtn"></div>
                                <button class="contact100-form-btn" name="btnConsultarSigno">
                                    Consultar seu signo
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php
        }
        include './js.php';
        ?>
    </body>
</html>